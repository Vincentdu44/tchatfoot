$(function() {
    $('.container').vegas({
        slides: [
            { src: 'images/european-championship-1383184__340.jpg' },
            { src: 'images/football-1406106__340.jpg' }
        ]
    });
});
