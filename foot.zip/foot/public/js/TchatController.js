var app = angular.module('app', ['firebase']); // une app initialisée


// configure l'affichage de nos données de la scope
app.config(function($interpolateProvider){
    $interpolateProvider.startSymbol('#{').endSymbol('}#');
});

//je crée un filtre
app.filter('ago', function(){

  return function(input){
    moment.locale('fr');//initialize moment en francais
    var dateTime = new Date(input);
    dateTime = moment(dateTime).fromNow();

    return dateTime;
  };
});

app.controller('TchatController', function TchatController($scope, $http,
  $interval) {

//$http: permet d'interroger une URL et de retourner les données en JSON
// $interval: permet d'executer une fonction à travers un interval de temps
  $scope.titre = "Borussia Dortmund - Monaco";


  $scope.tchats = [];

  // je charge mes données en JSON avec le module $http

  function areDiffrentByIds(a,b){
    var idsA = a.map( function(x){ return x.id; } ).sort();
    var idsB = b.map( function(x){ return x.id; } ).sort();
    return (idsA.join(',') !== idsB.join(',') );
  }

  $interval(function(){
    console.log($scope.take);
    $http.get('tchat/' + $scope.skipe + "/" + $scope.take)
    .then(function(response) {
      if(areDiffrentByIds($scope.tchats,response.data)){
        $scope.tchats = response.data;
      }
    });
  }, 5000);


$scope.skipe = 0;
$scope.take = 5;


$('#chat').scroll(function() {
  console.log($('#chat').scrollTop());
  if($('#chat').scrollTop() > 20) {
    $scope.take += 5;//augmenter le take de 5
  }
});

$scope.voirPlus = function(){

    $scope.take += 300;//augmenter le take de 300

};
//ajout d'un tchat
  $scope.add = function(){

    if($scope.content != undefined && $scope.content.length > 0){
//http post me permet de faire une REQUETE en post
      $http.post('/tchat-add', //url (uri)
      {'content' : $scope.content.trim() })
// content : name de mon input
//$scope.content : valeur de mon input
      //envoi de données

      .then(function(response) {
        $scope.content = '';
      });
    }
  };

});

//différence entre 2 tableaux d'objets par leur IDs
