<html>
	<head>
		<title>Formulaire</title>
  </head>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Formulaire d'inscription</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


												<?php if(count($errors) > 0): ?>
													<div class="alert alert-danger">
															<ul>
																	<?php foreach($errors->all() as $error): ?>
																	<li><?php echo e($error); ?></li>
																	<?php endforeach; ?>
															</ul>
													</div>
												<?php endif; ?>

                        <div class="form-group<?php echo e($errors->has('nom') ? ' has-error' : ''); ?>">
                            <label for="nom" class="col-md-4 control-label">Nom</label>

                            <div class="col-md-6">
                                <input id="nom" type="text" class="form-control" name="nom" value="<?php echo e(old('nom')); ?>">

                                <?php if($errors->has('nom')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nom')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('prenom') ? ' has-error' : ''); ?>">
                            <label for="prenom" class="col-md-4 control-label">Prénom</label>

                            <div class="col-md-6">
                                <input id="prenom" type="text" class="form-control" name="prenom" value="<?php echo e(old('prenom')); ?>">

                                <?php if($errors->has('prenom')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('prenom')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation">

                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('telephone') ? ' has-error' : ''); ?>">
                            <label for="telephone" class="col-md-4 control-label">Téléphone</label>

                            <div class="col-md-6">
                                <input id="telephone" type="text" class="form-control" name="telephone" value="<?php echo e(old('telephone')); ?>">

                                <?php if($errors->has('telephone')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('telephone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('code_postal') ? ' has-error' : ''); ?>">
                            <label for="code_postal" class="col-md-4 control-label">Code postal</label>

                            <div class="col-md-6">
                                <input id="code_postal" type="text" class="form-control" name="code_postal" value="<?php echo e(old('code_postal')); ?>">

                                <?php if($errors->has('code_postal')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('code_postal')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('biographie') ? ' has-error' : ''); ?>">
                            <label for="biographie" class="col-md-4 control-label">Biographie</label>

                            <div class="col-md-6">
                                <input id="biographie" type="text" class="form-control" name="biographie" value="<?php echo e(old('biographie')); ?>">

                                <?php if($errors->has('biographie')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('biographie')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('ville') ? ' has-error' : ''); ?>">
                            <label for="ville" class="col-md-4 control-label">Ville</label>

                            <div class="col-md-6">
                                <input id="ville" type="text" class="form-control" name="ville" value="<?php echo e(old('ville')); ?>">

                                <?php if($errors->has('ville')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('ville')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('birth') ? ' has-error' : ''); ?>">
                            <label for="birth" class="col-md-4 control-label">Date de Naissance</label>

                            <div class="col-md-6">
                                <input id="birth" type="text" placeholder="dd/mm/yyyy" class="form-control" name="birth" value="<?php echo e(old('birth')); ?>">

                                <?php if($errors->has('birth')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('birth')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                            <label for="image" class="col-md-4 control-label">Image</label>

                            <div class="col-md-6">
                                      <label for="exampleInputFile">File input</label>
                                      <input type="file" name="image" accept="image/*" capture id="exampleInputFile">
                                </div>

                                <?php if($errors->has('image')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-user"></i> Enregistrer
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</html>
