<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('/auth/login');
})->name('welcome');



Route::post('/','TchatController@add')->name('welcome');

Route::any('/tchat','TchatController@lister')->name('tchat.liste');

Route::any('/logout','AuthController@out')->name('tchat.out');

Route::get('/tchat/{skip?}/{take?}', function($skip = 0, $take = 5){
 // take() => limit à 6
 // orderBy: trié par id descendante
 return App\Tchat::select('tchat.id', 'tchat.content', 'tchat.created_at', 'tchat.updated_at', 'tchat.user_id', 'user.nom as nom', 'user.prenom as prenom', 'user.image as image')->join('user', 'user.id','=','tchat.user_id')->skip($skip)->take($take)->orderBy('id', 'desc')->get();
})
->name('tchat');

Route::post('/tchat-add','TchatController@add')->name('tchat-add');

Route::auth();
