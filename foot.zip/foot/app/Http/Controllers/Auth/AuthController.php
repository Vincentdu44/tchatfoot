<?php

namespace App\Http\Controllers\Auth;

use App\User;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = '/tchat';


    /**
    * Redirection après deconnexion
    */
    protected $redirectAfterLogout = '/';


    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware($this->guestMiddleware(), ['except' => 'logout']);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
          'nom'=>'required|min:3|regex:/^[A-Za-z\s]+$/',
          'prenom'=>'required|min:3|regex:/^[A-Za-z\s]+$/',
          'email'=>'required|email|unique:user',
          'password'=>'required|confirmed|regex:/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[\da-zA-Z]{6,}$/',
          'telephone'=>'required|regex:/^(([0-9]{2})[-. ]?){5}$/',
          'code_postal'=>'required|regex:/^[0-9]{5,5}$/',
          'biographie'=>'required|min:15',
          'ville'=>"required|regex:/^[[:alpha:]]([-' ]?[[:alpha:]])*$/",
          'birth'=>'required|date_format:d/m/Y',
          'file'=>'image|dimensions:min_width=100,min_height=200'
        ],[
          'required'=>'Le champs :attribute est obligatoire',
          'nom.regex' => "Le nom n'est pas valide",
          'prenom.regex' => "Le prénom n'est pas valide",
          'password.regex' => "Au moins un chiffre et une majuscule",
          'biographie.min' => '15 caractères MINIMUM'
      ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {

        $fileName = "";
        if (isset($data['image'])) {
          $destinationPath = public_path("/uploads/");
          $file = $data['image'];
          $fileName = $file->getClientOriginalName();
          $file->move($destinationPath, $fileName);
        }

        $dateformat =  \DateTime::createFromFormat('d/m/Y', $data ['birth']);
        return User::create([
            'nom' => $data['nom'],
            'prenom' => $data['prenom'],
            'image' => $fileName,
            'email' => $data['email'],
            'password' => bcrypt($data ['password']),
            'telephone' => $data['telephone'],
            'code_postal' => $data['code_postal'],
            'biographie' => $data['biographie'],
            'ville' => $data ['ville'],
            'birth' => $dateformat->format('Y-m-d'), //parser YYYY-MM-DD
        ]);
    }


    public function out() {

    Auth::logout();
    return Redirect::route('home');

}
}
