<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Tchat;

use Auth;



class TchatController extends Controller
{
  //add Tchat message in database
    public function add(Request $request){
      $tchat = new Tchat();
      $tchat->content = $request->content;
      $tchat->user_id = Auth::user()->id;
      $tchat->save();//created at at now()
      }


    public function lister(){

      $tchats = Tchat::all();

    return view('tchat',[
      'tchats' => $tchats]);
    }

}
